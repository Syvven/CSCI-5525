Noah Hendrickson (hend0800@umn.edu)
ID: 5520241

Instructions:
In terminal, 

> <python_command> <hw2_q2.py or hw2_q4.py>

to run.

Assumptions:
Only assumptions made are that the data is properly 
 formatted and that the threshold and number of iterations
 stays the same the whole time.