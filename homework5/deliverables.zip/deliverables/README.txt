Noah Hendrickson
5520241
hend0800@umn.edu

How to run:

cd into directory containing code.
"<python cmd> hw5_q2.py" in terminal.

Assumtions:

None