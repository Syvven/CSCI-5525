Name:  Noah Hendrickson
ID:    5520241
Email: hend0800@umn.edu

How To Run:

In terminal, when cd'd into directory containing code,
input "py hw3_qN.py" where the capital N is replaced with 2 or 3
for which question you want to run. 

Assumptions being made include having a folder in same directory
as the python files called "model_saves" which contains two files 
that are named cnn_best_model.pt and mlp_best_model.pt
Another assumption is that the predictions are not actually 
needed to be returned from the predict function. 
Outside of those and the ones specified by the hw writeup,
there are no other assumptions.